package com.example.nimarket

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
