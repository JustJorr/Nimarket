import 'dart:io';
import 'package:flutter/material.dart';
import '../../models/shop.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../services/supabase_image_upload.dart';
import 'package:device_info_plus/device_info_plus.dart';

class ManageShopsScreen extends StatefulWidget {
  final List<Shop> shops;
  final Function(Shop) onShopAdded;
  final VoidCallback? onRefresh;

  const ManageShopsScreen({required this.shops, required this.onShopAdded, this.onRefresh, super.key});

  @override
  State<ManageShopsScreen> createState() => _ManageShopsScreenState();
}

class _ManageShopsScreenState extends State<ManageShopsScreen> {
  final _uploader = SupabaseImageUpload();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Manage Shops", style: TextStyle(color: Colors.white)),
        backgroundColor: Color.fromARGB(255, 7, 12, 156),
        foregroundColor: Colors.amber,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color.fromARGB(255, 7, 12, 156),
              Color.fromARGB(255, 4, 3, 49),
            ],
          ),
        ),
        child: ListView.builder(
          itemCount: widget.shops.length,
          itemBuilder: (ctx, i) {
            final shop = widget.shops[i];
            return Card(
              color: const Color.fromARGB(255, 4, 3, 49),
              child: ListTile(
                title: Text(shop.name, style: const TextStyle(color: Colors.amber)),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(shop.description, style: const TextStyle(color: Colors.white)),
                    Text('Rating: ${shop.rating.toStringAsFixed(1)} ⭐', style: const TextStyle(color: Colors.yellow, fontSize: 12)),
                  ],
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.star, color: Colors.yellow),
                      onPressed: () => _showEditRatingDialog(shop),
                    ),
                    Switch(
                      value: shop.active,
                      onChanged: (val) async {
                        setState(() => shop.active = val);
                        await FirebaseFirestore.instance.collection('shops').doc(shop.id).update({'active': val});
                      },
                      activeColor: Colors.amber,
                      inactiveThumbColor: Colors.grey,
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _deleteShop(shop),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.amber,
        foregroundColor: const Color.fromARGB(255, 37, 0, 157),
        child: const Icon(Icons.add),
        onPressed: () => _showAddShopDialog(context),
      ),
    );
  }

  Future<bool> requestImagePermission() async {
  if (Platform.isIOS) {
    final status = await Permission.photos.request();
    return status.isGranted;
  }

  if (Platform.isAndroid) {
    final deviceInfo = DeviceInfoPlugin();
    final androidInfo = await deviceInfo.androidInfo;
    final sdk = androidInfo.version.sdkInt;

    if (sdk >= 33) {
      final status = await Permission.photos.request();
      return status.isGranted;
    }

    final status = await Permission.storage.request();
    return status.isGranted;
  }

  return false;
  }



  Future<void> _deleteShop(Shop shop) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Shop'),
        content: Text('Are you sure you want to delete "${shop.name}"? This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), style: ElevatedButton.styleFrom(backgroundColor: Colors.red), child: const Text('Delete')),
        ],
      ),
    );

    if (confirm == true) {
      try {
        await FirebaseFirestore.instance.collection('shops').doc(shop.id).delete();
        setState(() => widget.shops.remove(shop));
        widget.onRefresh?.call();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Shop "${shop.name}" deleted.')));
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to delete shop: $e')));
      }
    }
  }

  void _showEditRatingDialog(Shop shop) {
    final ratingController = TextEditingController(text: shop.rating.toStringAsFixed(1));

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit Rating for ${shop.name}'),
        content: TextField(
          controller: ratingController,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Rating (0.0 - 5.0)'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              final newRating = double.tryParse(ratingController.text);
              if (newRating == null || newRating < 0 || newRating > 5) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Invalid rating. Must be between 0.0 and 5.0')));
                return;
              }

              try {
                await FirebaseFirestore.instance.collection('shops').doc(shop.id).update({'rating': newRating});
                setState(() => shop.rating = newRating);
                widget.onRefresh?.call();
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Rating updated for ${shop.name}')));
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to update rating: $e')));
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _showAddShopDialog(BuildContext context) {
    final nameController = TextEditingController();
    final descController = TextEditingController();
    File? selectedImage;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateDialog) {
            return AlertDialog(
              title: const Text("Add New Shop"),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(controller: nameController, decoration: const InputDecoration(labelText: "Shop Name")),
                    TextField(controller: descController, decoration: const InputDecoration(labelText: "Description")),
                    const SizedBox(height: 10),
                    ElevatedButton(
                      onPressed: () async {
                        final allowed = await requestImagePermission();
                        if (!allowed) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Permission denied. Cannot access gallery.')),
                          );
                          return;
                        }
                        final picker = ImagePicker();
                        final picked = await picker.pickImage(source: ImageSource.gallery);
                        if (picked != null) setStateDialog(() => selectedImage = File(picked.path));
                      },
                      child: const Text("Select Banner Image"),
                    ),
                    if (selectedImage != null) Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Text("Selected: ${selectedImage!.path.split('/').last}", style: const TextStyle(fontSize: 12)),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
                ElevatedButton(
                  onPressed: () async {
                    if (nameController.text.isEmpty) return;

                    String bannerUrl = '';
                    if (selectedImage != null) {
                      final url = await _uploader.uploadImage(selectedImage!, 'shop_banners', bucketName: 'shops');
                      if (url == null) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Banner upload failed.')));
                        return;
                      }
                      bannerUrl = url;
                    }

                    try {
                      final doc = FirebaseFirestore.instance.collection('shops').doc();
                      final newShop = Shop(
                      id: doc.id,
                      name: nameController.text,
                      description: descController.text,
                      bannerUrl: bannerUrl,
                      active: true,
                      items: [],
                    );

                      await doc.set(newShop.toMap());
                      widget.onShopAdded(newShop);
                      widget.onRefresh?.call();
                      Navigator.pop(context);
                    } catch (e) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to save shop: $e')));
                    }
                  },
                  child: const Text("Add"),
                ),
              ],
            );
          },
        );
      },
    );
  }
}
